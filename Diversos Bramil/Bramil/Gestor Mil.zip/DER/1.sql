/*
Created		22/10/2002
Modified		10/01/2003
Project		Gestor Mil
Model		Gestor Mil
Company		Grupo Mil
Author		Equipe Desenvolvimento
Version		1.0
Database		MS SQL 2000 
*/







Create table [TBErros] (
	[PKNumero_TBErro] Float NOT NULL,
	[DFDescricao_TBErro] Nvarchar(500) NOT NULL,
Primary Key ([PKNumero_TBErro])
) 
go

Create table [TBLog_erro] (
	[PFKId_TBLog] Integer NOT NULL,
	[FKNumero_TBErro] Float NOT NULL,
Primary Key ([PFKId_TBLog])
) 
go

Create table [TBSolucoes_erro] (
	[PKId_TBSolucoes_erro] Integer NOT NULL,
	[FKNumero_TBErro] Float NOT NULL,
	[DFDescricao_TBSolucoes_erro] Nvarchar(500) NOT NULL,
Primary Key ([PKId_TBSolucoes_erro])
) 
go











Alter table [TBSolucoes_erro] add  foreign key([FKNumero_TBErro]) references [TBErros] ([PKNumero_TBErro])  on update no action on delete no action 
go
Alter table [TBLog_erro] add  foreign key([FKNumero_TBErro]) references [TBErros] ([PKNumero_TBErro])  on update no action on delete no action 
go


Set quoted_identifier on
go












Set quoted_identifier off
go


