/*
Created		23/10/2002
Modified		03/06/2003
Project		Gestor Mil
Model		
Company		Grupo Mil
Author		Equipe Desenvolvimento
Version		1.0
Database		MS SQL 2000 
*/







Create table [TBGrupo_usuario] (
	[PKCodigo_TBGrupo_usuario] Integer NOT NULL,
	[DF_Descricao_TBGrupo_usuario] Nvarchar(40) NOT NULL,
Primary Key ([PKCodigo_TBGrupo_usuario])
) 
go

Create table [TBMenu] (
	[PKId_TBMenu] Integer Identity NOT NULL,
	[DFOrdem_TBMenu] Integer NOT NULL,
	[DFDescricao_TBMenu] Nvarchar(20) NOT NULL,
Primary Key ([PKId_TBMenu])
) 
go

Create table [TBSubmenu] (
	[PKId_TBSubmenu] Integer Identity NOT NULL,
	[FKId_TBMenu] Integer NOT NULL,
	[DFOrdem_TBSubmenu] Integer NOT NULL,
	[DFDescricao_TBSubmenu] Nvarchar(20) NULL,
	[DFPrograma_TBSubmenu] Nvarchar(20) NOT NULL,
	[DFTipo_TBSubmenu] Integer NULL,
Primary Key ([PKId_TBSubmenu])
) 
go

Create table [TBAcessibilidade] (
	[PKId_TBAcessibilidade] Integer Identity NOT NULL,
	[FKId_TBModulo] Integer NOT NULL,
	[FKCodigo_TBUsuario] Integer NOT NULL,
	[DFInclusao_TBAcessibilidade] Bit NOT NULL,
	[DFExclusao_TBAcessibilidade] Bit NOT NULL,
	[DFConsulta_TBAcessibilidade] Bit NOT NULL,
	[DFAlteracao_TBAcessibilidade] Bit NOT NULL,
	[DFAcesso_TBAcessibilidade] Bit NOT NULL,
Primary Key ([PKId_TBAcessibilidade])
) 
go

Create table [TBScript] (
	[PKId_TBScript] Integer Identity NOT NULL,
	[DFNome_TBScript] Nvarchar(20) NOT NULL,
	[DFObjetivo_TBScript] Nvarchar(100) NOT NULL,
	[DFData_execucao_TBScript] Smalldatetime NOT NULL,
Primary Key ([PKId_TBScript])
) 
go

Create table [TBLocalizacao] (
	[PKId_TBLocalizacao] Integer Identity NOT NULL,
	[IXNome_TBLocalizacao] Nvarchar(50) NOT NULL,
	[DFCaminho_TBLocalizacao] Char(50) NOT NULL,
	[DFObservacao_TBLocalizacao] Char(100) NULL,
Primary Key ([PKId_TBLocalizacao])
) 
go

Create table [TBEmpresa] (
	[PKCodigo_TBEmpresa] Integer NOT NULL,
	[DFRazao_Social_TBEmpresa] Nvarchar(40) NOT NULL,
	[DFNome_fantasia_TBEmpresa] Nvarchar(20) NOT NULL,
	[DFNome_reduzido_TBEmpresa] Nvarchar(20) NOT NULL UNIQUE,
	[DFEndereco_TBEmpresa] Nvarchar(40) NOT NULL,
	[DFNumero_TBEmpresa] Nvarchar(10) NOT NULL,
	[DFComplemento_TBEmpresa] Nvarchar(20) NULL,
	[DFBairro_TBEmpresa] Nvarchar(30) NOT NULL,
	[FKId_TBCidade_gestor] Integer NOT NULL,
	[DFCep_TBEmpresa] Nvarchar(10) NOT NULL,
	[DFEmail_TBEmpresa] Nvarchar(50) NULL,
	[DFHome_page_TBEmpresa] Nvarchar(50) NULL,
	[DFCnpj_TBEmpresa] Nchar(20) NOT NULL,
	[DFInscricao_estadual_TBEmpresa] Nvarchar(20) NOT NULL,
	[DFInscricao_municipal_TBEmpresa] Nvarchar(20) NOT NULL,
	[DFPorte_loja_TBEmpresa] Integer NOT NULL,
	[DFTelefone_TBEmpresa] Nvarchar(20) NULL,
	[DFFax_TBEmpresa] Nvarchar(20) NULL,
	[DFNumero_funcionarios_TBEmpresa] Integer NULL,
Primary Key ([PKCodigo_TBEmpresa])
) 
go

Create table [dbo].[TBLogradouro] (
	[PKCodigo_TBLogradouro] Integer NOT NULL,
	[DFNome_TBLogradouro] Nvarchar(125) NULL,
	[DFNome_resumido_TBLogradouro] Nvarchar(70) NOT NULL,
	[DFNome_resumido_sem_acento_TBLogradouro] Nvarchar(70) NOT NULL,
	[DFComplemento_TBLogradouro] Nvarchar(100) NULL,
	[FKBairro_seq_inicial_TBLogradouro] Integer NULL,
	[FKBairro_seq_final_TBLogradouro] Integer NULL,
	[DFCep_TBLogradouro] Nvarchar(8) NOT NULL,
	[FKCodigo_cidade_TBLogradouro] Integer NOT NULL,
	[DFUf_seguranca_TBLogradouro] Nvarchar(2) NOT NULL,
Primary Key ([PKCodigo_TBLogradouro])
) 
go

Create table [dbo].[TBBairro] (
	[PKCodigo_TBBairro] Integer NOT NULL,
	[DFNome_bairro_TBBairro] Nvarchar(72) NOT NULL,
	[DFNome_bairro_abreviado_TBBairro] Nvarchar(36) NULL,
	[FKCodigo_cidade_TBBairro] Integer NOT NULL,
	[DFUf_TBBairro] Nvarchar(2) NOT NULL,
Primary Key ([PKCodigo_TBBairro])
) 
go

Create table [dbo].[TBCidade] (
	[PKCodigo_TBCidade] Integer NOT NULL,
	[DFNome_cidade_TBCidade] Nvarchar(60) NULL,
	[DFNome_cidade_abreviado_TBCidade] Nvarchar(50) NOT NULL,
	[DFCep_TBCidade] Nvarchar(8) NULL,
	[DFUf_seguranca_TBCidade] Nvarchar(2) NOT NULL,
Primary Key ([PKCodigo_TBCidade])
) 
go

Create table [TBEstrutura_mercadologica] (
	[PKCodigo_TBEstrutura_mercadologica] Integer NOT NULL,
	[DFDescriao_TBEstrutura_mercadologica] Nvarchar(40) NOT NULL,
	[DFTipo_estrutura_TBEstrutura_mercadologica] Bit NOT NULL,
Primary Key ([PKCodigo_TBEstrutura_mercadologica])
) 
go

Create table [TBSecao] (
	[PKId_TBSecao] Integer Identity NOT NULL,
	[FKCodigo_TBEstrutura_mercadologica] Integer NOT NULL,
	[IXCodigo_TBSecao] Integer NOT NULL,
	[DFDescricao_TBsecao] Nvarchar(40) NOT NULL,
Primary Key ([PKId_TBSecao])
) 
go

Create table [TBGrupo] (
	[PKId_TBGrupo] Integer Identity NOT NULL,
	[FKId_TBSecao] Integer NOT NULL,
	[IXCodigo_TBGrupo] Integer NOT NULL,
	[DFDescricao_TBGrupo] Nvarchar(40) NOT NULL,
Primary Key ([PKId_TBGrupo])
) 
go

Create table [TBSubgrupo] (
	[PKId_TBSubgrupo] Integer Identity NOT NULL,
	[FKId_TBGrupo] Integer NOT NULL,
	[IXCodigo_TBSubgrupo] Integer NOT NULL,
	[DFDescricao_TBSubgrupo] Nvarchar(40) NOT NULL,
Primary Key ([PKId_TBSubgrupo])
) 
go

Create table [TBCategoria] (
	[PKId_TBCategoria] Integer Identity NOT NULL,
	[FKId_TBSubgrupo] Integer NOT NULL,
	[IXCodigo_TBCategoria] Integer NULL,
	[DFDescricao_TBCategoria] Nvarchar(40) NULL,
Primary Key ([PKId_TBCategoria])
) 
go

Create table [TBFornecedor] (
	[PKCodigo_TBFornecedor] Integer NOT NULL,
	[DFRazao_social_TBFornecedor] Nvarchar(40) NOT NULL,
	[DFNome_fantasia_TBFornecedor] Nvarchar(20) NOT NULL,
	[DFStatus_TBFornecedor] Integer NOT NULL,
	[DFGrupo_TBFornecedor] Integer NOT NULL,
	[DFClasse_TBFornecedor] Integer NOT NULL,
	[DFIndenizacao_TBFornecedor] Integer NOT NULL,
	[DFDespacho_mercadoria_TBFornecedor] Integer NOT NULL,
	[DFValor_troca_mercadoria_TBFornecedor] Integer NOT NULL,
	[DFConsignacao_TBFornecedor] Bit NOT NULL,
	[DFVerba_TBFornecedor] Bit NOT NULL,
	[DFPeriodo_visita_TBFornecedor] Integer NOT NULL,
	[DFTipo_frete_TBFornecedor] Bit NOT NULL,
	[DFDesconto_promocional_TBFornecedor] Decimal(3,2) NULL,
	[DFPrazo_adcional_promocao_TBFornecedor] Integer NULL,
	[DFPrazo_entrega_TBFornecedor] Integer NULL,
	[FKCodigo_TBCondicao_pagamento] Integer NOT NULL,
	[DFPercentual_icms_TBFornecedor] Decimal(2,2) NULL,
	[FKCodigo_TBBanco] Integer NOT NULL,
	[DFAgencia_banco_TBfornecedor] Char(5) NULL,
	[DFConta_banco_TBFornecedor] Char(10) NULL,
	[DFData_inclusao_TBFornecedor] Smalldatetime NOT NULL,
	[DFUsuario_inclusao_TBFornecedor] Nvarchar(20) NOT NULL,
	[DFData_ultima_alteracao_TBFornecedor] Smalldatetime NULL,
	[DFUsuario_ultima_alteracao_TBFornecedor] Nvarchar(20) NULL,
Primary Key ([PKCodigo_TBFornecedor])
) 
go

Create table [TBAgenda_fornecedor] (
	[DFId_TBAgenda_fornecedor] Integer Identity NOT NULL,
	[FKCodigo_TBFornecedor] Integer NOT NULL,
	[DFContato_TBAgenda_fornecedor] Nvarchar(30) NULL,
	[DFDepartamento_TBAgenda_fornecedor] Nvarchar(20) NULL,
	[DFTipo_TBAgenda_fornecedor] Char(1) NULL,
	[DFNumero_TBAgenda_fornecedor] Nvarchar(20) NULL,
	[DFEmail_TBAgenda_fornecedor] Nvarchar(40) NULL,
	[DFIntegra_siga_TBAgenda_fornecedor] Bit NOT NULL,
	[DFObservacao_TBAgenda_fornecedor] Nvarchar(40) NULL,
Primary Key ([DFId_TBAgenda_fornecedor])
) 
go

Create table [TBComprador] (
	[PKCodigo_TBComprador] Integer NOT NULL,
	[DFNome_TBComprador] Nvarchar(40) NULL,
Primary Key ([PKCodigo_TBComprador])
) 
go

Create table [TBCondicao_pagamento] (
	[PKCodigo_TBCondicao_pagamento] Integer NOT NULL,
	[DFDescricao_TBCondicao_pagamento] Nvarchar(40) NOT NULL,
	[DFParcelas_TBCondicao_pagamento] Nvarchar(40) NOT NULL,
	[DFCalculo_apartir_TBCondicao_pagamento] Char(1) NOT NULL,
Primary Key ([PKCodigo_TBCondicao_pagamento])
) 
go

Create table [TBFornecedor_filial] (
	[PKId_TBFornecedor_filial] Integer Identity NOT NULL,
	[PKCodigo_TBFornecedor] Integer NOT NULL,
	[DFEndereco_TBFornecedor_filial] Nvarchar(40) NOT NULL,
	[DFNumero_TBFornecedor_filial] Nvarchar(10) NOT NULL,
	[DFComplemento_TBFornecedor_filial] Nvarchar(20) NULL,
	[DFBairro_TBFornecedor_filial] Nvarchar(30) NOT NULL,
	[FKId_TBCidade_gestor] Integer NOT NULL,
	[DFCep_TBFornecedor_filial] Nvarchar(10) NOT NULL,
	[DFTipo_pessoa_TBFornecedor_filial] Char(1) NOT NULL,
	[DFCgc_TBFornecedor_filial] Nvarchar(20) NOT NULL,
	[DFInscricao_estadual_TBFornecedor_filial] Nvarchar(20) NOT NULL,
Primary Key ([PKId_TBFornecedor_filial])
) 
go

Create table [TBCidade_gestor] (
	[PKId_TBCidade_gestor] Integer Identity NOT NULL,
	[IXCodigo_Correios_TBCidade_gestor] Integer NULL,
	[DFNome_TBCidade_gestor] Nvarchar(40) NOT NULL,
	[DFPais_TBCidade_gestor] Char(2) Default BR NOT NULL,
	[DFUf_TBCidade_gestor] Char(2) NOT NULL,
	[DFPopula��o_TBCidade_gestor] Integer NULL,
Primary Key ([PKId_TBCidade_gestor])
) 
go

Create table [TBBanco] (
	[PKCodigo_TBBanco] Integer NOT NULL,
	[DFNome_TBBanco] Nvarchar(40) NOT NULL,
Primary Key ([PKCodigo_TBBanco])
) 
go

Create table [TBObra] (
	[PKCodigo_TBObra] Integer NOT NULL,
	[DFNome_TBObra] Nvarchar(40) NOT NULL,
	[DFEndereco_Padrao_TBObra] Nvarchar(40) NOT NULL,
	[DFBairro_TBObra] Nvarchar(30) NULL,
	[FKId_TBCidade_gestor] Integer NOT NULL,
	[DFCep_TBObra] Integer NULL,
Primary Key ([PKCodigo_TBObra])
) 
go

Create table [TBClientes_construtora] (
	[PKCodigo_TBClientes_construtora] Integer NOT NULL,
	[FKId_TBCidade_gestor] Integer NOT NULL,
	[DFNome_TBClientes] Nvarchar(40) NOT NULL,
	[DFEndereco_TBClientes_construtora] Nvarchar(40) NOT NULL,
	[DFNumero_TBClientes_contrutora] Nvarchar(10) NOT NULL,
	[DFComplemento_TBClientes_construtora] Nvarchar(20) NULL,
	[DFBairro_TBClientes_construtora] Nvarchar(30) NOT NULL,
	[DFCep_TBClientes_construtora] Nvarchar(10) NOT NULL,
	[DFTipo_pessoa_TBClientes_construtora] Bit Default 0 NOT NULL,
	[DFCnpj_cpf_TBClientes_construtora] Nvarchar(20) NOT NULL,
	[DFData_emissao_Cnpj_Cpf_TBClientes_construtora] Smalldatetime NOT NULL,
	[DFProfissao_TBClientes_construtora] Nvarchar(40) NOT NULL,
	[DFData_aniversario_TBClientes_construtora] Smalldatetime NOT NULL,
	[DFEmail_TBClientes_construtora] Nvarchar(50) NULL,
	[DFHome_page_TBClientes_construtora] Nvarchar(50) NULL,
Primary Key ([PKCodigo_TBClientes_construtora])
) 
go

Create table [TBSolicitacao_servico] (
	[PKCodigo_TBSolicitacao_servico] Integer NOT NULL,
	[FKCodigo_TBClientes_construtora] Integer NOT NULL,
	[DFSolicitante_TBSolicitacao_servico] Nvarchar(40) NOT NULL,
	[DFTelefone_contato_TBSolicitacao_servico] Nvarchar(20) NULL,
	[DFDescricao_problemas_TBSolicitacao_servico] Nvarchar(1000) NOT NULL,
	[DFObservacoes_TBSolicitacao_servico] Nvarchar(500) NULL,
	[DFUsuario_lancamento_TBSolicitacao_servico] Nvarchar(30) NOT NULL,
	[DFData_lancamento] Smalldatetime NULL,
	[DFStatus_TBSolicitacao_servico] Char(1) NOT NULL,
	[DFData_aprovacao_TBSolicitacao_servico] Smalldatetime NULL,
	[DFResponsavel_aprovacao_TBSolicitacao_servico] Nvarchar(20) NULL,
Primary Key ([PKCodigo_TBSolicitacao_servico])
) 
go

Create table [TBOrdem_servico] (
	[PKCodigo_TBOrdem_servico] Integer NOT NULL,
	[FKCodigo_TBSolicitacao_servico] Integer NOT NULL,
	[DFServicos_aexecutar_TBOrdem_servico] Nvarchar(1000) NOT NULL,
	[DFPessoal_TBOrdem_servico] Nvarchar(500) NOT NULL,
	[DFResponsavel_TBOrdem_servico] Nvarchar(40) NOT NULL,
	[DFData_inicio_TBOrdem_servico] Smalldatetime NOT NULL,
	[DFPrevisao_termino_TBOrdem_servico] Smalldatetime NOT NULL,
	[DFObservacao_TBOrdem_servico] Nvarchar(100) NULL,
	[DFAtendimento_TBOrdem_servico] Char(1) NOT NULL,
	[DFQualidade_TBOrdem_servico] Char(1) Default "N" NOT NULL,
	[DFComportamento_TBOrdem_servico] Char(1) Default "N" NOT NULL,
	[DFTempo_resolucao_TBOrdem_servico] Char(1) Default "N" NOT NULL,
	[DFLimpeza_TBOrdem_servico] Char(1) Default "N" NOT NULL,
Primary Key ([PKCodigo_TBOrdem_servico])
) 
go

Create table [TBCusto_servico] (
	[PKCodigo_TBCusto_servico] Integer NOT NULL,
	[DFObservacoes_TBCusto_servico] Nvarchar(500) NULL,
	[DFData_levantamento_TBCusto_servico] Smalldatetime NOT NULL,
	[DFResponsavel_TBCusto_servico] Nvarchar(40) NOT NULL,
	[DFDesconto_TBCusto_servico] Money NULL,
Primary Key ([PKCodigo_TBCusto_servico])
) 
go

Create table [TBAgenda_clientes_construtora] (
	[PKId_TBAgenda_clientes_construtora] Integer Identity NOT NULL,
	[FKCodigo_TBClientes_construtora] Integer NOT NULL,
	[DFContato_TBAgenda_clientes_construtora] Nvarchar(30) NULL,
	[DFDepartamento_TBAgenda_clientes_construtora] Nvarchar(20) NULL,
	[DFTipo_TBAgenda_fornecedor] Char(1) NULL,
	[DFNumero_TBAgenda_clientes_construtora] Nvarchar(20) NULL,
	[DFObservacao_TBAgenda_clientes_construtora] Nvarchar(40) NULL,
Primary Key ([PKId_TBAgenda_clientes_construtora])
) 
go

Create table [TBCusto_detalhamento] (
	[DFId_TBCusto_detalhamento] Integer Identity NOT NULL,
	[FKCodigo_TBCusto_servico] Integer NOT NULL,
	[DFAtividade_TBCusto_detalhamento] Nvarchar(60) NOT NULL,
	[DFMaterial_TBCusto_detalhamento] Nvarchar(50) NOT NULL,
	[DFUnidade_TBCusto_detalhamento] Char(3) NOT NULL,
	[DFQuantidade_TBCusto_detalhamento] Decimal(10,2) NOT NULL,
	[DFPreco_unitario_TBCusto_detalhamento] Money NOT NULL,
Primary Key ([DFId_TBCusto_detalhamento])
) 
go

Create table [TBClassificacao_fiscal] (
	[PKId_TBClassificacao_fiscal] Integer Identity NOT NULL,
	[DFCodigo_cfo_TBClassificacao_fiscal] Integer NOT NULL,
	[DFDescricao_TBClassificacao_fiscal] Nvarchar(40) NOT NULL,
	[DFObservacao_TBClassificacao_fiscal] Nvarchar(50) NULL,
	[DFTipo_operacao_TBClassificacao_fiscal] Bit NOT NULL,
	[DFTipo_cadastro_TBClassificacao_fiscal] Char(1) NOT NULL,
	[DFTipo_preco_TBClassificacao_fiscal] Integer NOT NULL,
	[DFInforma_quantidade_TBClassificacao_fiscal] Bit NOT NULL,
	[DFCalcula_icms_TBClassificacao_fiscal] Bit NOT NULL,
	[DFCredita_icms_TBClassificacao_fiscal] Bit NOT NULL,
	[DFCalcula_diferenca_aliquota_icms_TBClassificacao_fiscal] Bit NOT NULL,
	[DFPercentual_reducao_icms_TBClassificacao_fiscal] Bit NOT NULL,
	[DFColuna_livro_fiscal_TBClassificacao_fiscal] Char(1) NOT NULL,
	[DFCalcula_ipi_TBClassificacao_fiscal] Bit NOT NULL,
	[DFCredita_ipi_TBClassificacao_fiscal] Bit NOT NULL,
	[DFDestaca_ipi_TBClassificacao_fiscal] Bit NOT NULL,
	[DFIncide_ipi_TBClassificacao_fiscal] Bit NOT NULL,
	[DFCalcula_iss_TBClassificacao_fiscal] Bit NOT NULL,
	[DFAtualiza_duplicata_TBClassificacao_fiscal] Bit NOT NULL,
	[DFAtualiza_estoque_TBClassificacao_fiscal] Bit NOT NULL,
	[DFAtualiza_preco_compra_TBClassificacao_fiscal] Bit NOT NULL,
	[DFAtualiza_giro_TBClassificacao_fiscal] Bit NOT NULL,
	[DFAtualiza_ultima_entrada_TBClassificacao_fiscal] Bit NOT NULL,
	[DFAtualiza_ultima_saida_TBClassificacao_fiscal] Bit NOT NULL,
	[DFStatus_matriz_TBClassificacao_fiscal] Integer NOT NULL,
	[DFData_alteracao_status_matriz_TBClassificacao_fiscal] Smalldatetime NOT NULL,
	[DFStatus_loja_TBClassificacao_fiscal] Integer NOT NULL,
	[DFData_alteracao_status_loja_TBClassificacao_fiscal] Integer NOT NULL,
Primary Key ([PKId_TBClassificacao_fiscal])
) 
go

Create table [TBProduto] (
	[PKCodigo_TBProduto] Integer NOT NULL,
	[DFDescricao_TBProduto] Nvarchar(40) NOT NULL,
	[DFDescricao_gondola_TBProduto] Nvarchar(40) NOT NULL,
	[DFDescricao_resumida_TBProduto] Nvarchar(10) NOT NULL,
	[FKCodigo_TBComprador] Integer NOT NULL,
	[DFCst_TBProduto] Integer NOT NULL,
	[DFUnidade_compra_TBProduto] Char(3) NOT NULL,
	[DFFator_conversao_compra_TBProduto] Integer NOT NULL,
	[DFUnidade_venda_TBProduto] Char(3) NOT NULL,
	[DFFator_conversao_venda_TBProduto] Integer NOT NULL,
	[DFPeso_liquido_TBProduto] Decimal(5,3) NOT NULL,
	[DFPeso_bruto_TBProduto] Decimal(5,3) NOT NULL,
	[DFPercentual_ipi_TBProduto] Decimal(3,2) NULL,
	[DFStatus_TBProduto] Integer NOT NULL,
	[DFData_alteracao_status_TBProduto] Smalldatetime NOT NULL,
	[DFTipo_TBProduto] Integer NOT NULL,
	[DFCompra_suspensa_TBProduto] Char(10) NOT NULL,
	[DFTipo_pedido_TBProduto] Integer NOT NULL,
	[DFPerecivel_TBProduto] Integer NOT NULL,
	[DFTecla_atalho_balanca_TBProduto] Char(1) NULL,
	[DFData_cadastro_TBProduto] Smalldatetime NOT NULL,
	[DFUsuario_cadastro_TBProduto] Nvarchar(20) NOT NULL,
Primary Key ([PKCodigo_TBProduto])
) 
go

Create table [TBProduto_fornecedor] (
	[PKId_TBProduto_fornecedor] Integer Identity NOT NULL,
	[PKCodigo_TBFornecedor] Integer NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[DFPart_number_TBProduto_fornecedor] Nvarchar(20) NULL,
	[DFIntegra_siga_TBProduto_fornecedor] Bit NULL,
Primary Key ([PKId_TBProduto_fornecedor])
) 
go

Create table [TBCodigo_barras] (
	[DFId_TBCodigo_barras] Integer Identity NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[DFCodigo_TBCodigo_barras] Float NULL,
Primary Key ([DFId_TBCodigo_barras])
) 
go

Create table [TBProduto_empresa] (
	[PKId_TBProduto_empresa] Integer Identity NOT NULL,
	[FKCodigo_TBEmpresa] Integer NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[DFPertence_mix_TBProduto_empresa] Bit NOT NULL,
	[DFEstoque_atual_TBProduto_empresa] Decimal(12,3) NULL,
	[DFEstoque_maximo_TBProduto_empresa] Decimal(12,3) NULL,
	[DFEstoque_minimo_TBProduto_empresa] Decimal(12,3) NULL,
	[DFPonto_pedido_TBProduto_empresa] Decimal(12,3) NULL,
	[DFCusto_bruto_TBProduto_empresa] Money NULL,
	[DFCusto_liquido_TBProduto_empresa] Money NULL,
	[DFCusto_medio_TBProduto_empresa] Money NULL,
	[DFPreco_sugerido_TBProduto_empresa] Money NULL,
	[DFPreco_venda_TBProduto_empresa] Money NULL,
	[DFPreco_promocao_TBProduto_empresa] Money NULL,
	[DFData_inicio_promocao_TBProduto_empresa] Smalldatetime NULL,
	[DFData_final_promocao_TBProduto_empresa] Smalldatetime NULL,
	[DFTipo_preco_praticado_TBProduto_empresa] Integer NULL,
	[DFData_alteracao_preco_TBProduto_empresa] Smalldatetime NULL,
	[DFUsuario_alteracao_preco_TBProduto_empresa] Nvarchar(20) NULL,
	[DFPreco_venda_anterior_TBProduto_empresa] Money NULL,
	[DFCusto_bruto_anterior_TBProduto_empresa] Money NULL,
	[DFCusto_liquido_anterior_TBProduto_empresa] Money NULL,
	[DFCusto_medio_anterior_TBProduto_empresa] Money NULL,
	[DFData_alteracao_anterior_TBProduto_empresa] Smalldatetime NULL,
	[DFUsuario_anterior_alteracao_preco_TBProduto_empresa] Nvarchar(20) NULL,
	[DFTipo_atualizacao_preco_TBProduto_empresa] Integer NOT NULL,
	[DFTipo_controle_estoque_TBProduto_empresa] Integer NOT NULL,
	[DFMargem_liquida_TBProduto_empresa] Decimal(3,2) NULL,
	[DFMargem_liquida_anterior_TBProduto_empresa] Decimal(3,2) NULL,
	[DFMargem_bruta_TBProduto_empresa] Decimal(3,2) NULL,
	[DFMargem_bruta_anteriror_TBProduto_empresa] Decimal(3,2) NULL,
	[DFMargem_retido_entrada_TBProduto_empresa] Decimal(3,2) NULL,
	[DFMargem_retido_saida_TBProduto_empresa] Decimal(3,2) NULL,
	[DFPercentual_icms_retido_entrada_TBProduto_empresa] Decimal(3,2) NULL,
	[DFPercentual_icms_retido_saida_TBProduto_empresa] Decimal(3,2) NULL,
	[DFData_ultima_compra_TBProduto_empresa] Smalldatetime NOT NULL,
	[DFPreco_liquido_ultima_compra_TBProduto_empresa] Money NOT NULL,
	[DFQuantidade_ultima_compra_TBProduto_empresa] Decimal(10,3) NULL,
Primary Key ([PKId_TBProduto_empresa])
) 
go

Create table [TBBem] (
	[PKCodigo_TBBem] Integer NOT NULL,
	[FKId_TBClassificacao_fiscal] Integer NOT NULL,
	[FKCodigo_TBClasse] Integer NOT NULL,
	[FKCodigo_TBSituacao] Integer NOT NULL,
	[DFDescricao_TBBem] Nvarchar(200) NOT NULL,
	[DFDescricao_resumida_TBBem] Nvarchar(40) NOT NULL,
	[DFMarca_TBBem] Nvarchar(30) NULL,
	[DFNumero_fabricacao_TBBem] Nvarchar(30) NULL,
	[DFModelo_TBBem] Nvarchar(30) NULL,
	[DFSerie_TBBem] Nvarchar(20) NULL,
	[DFVinculo_TBBem] Integer NULL,
	[DFData_aquisicao_TBBem] Smalldatetime NOT NULL,
	[FKCodigo_TBFornecedor] Integer NOT NULL,
	[DFNumero_nota_TBBem] Integer NOT NULL,
	[DFSerie_nota_TBBem] Char(3) NULL,
	[DFValor_TBBem] Money NOT NULL,
	[DFBase_icms_TBBem] Money NULL,
	[DFAliquota_icms_TBBem] Decimal(2,2) NULL,
	[DFValor_icms_TBBem] Money NULL,
	[DFIcms_frete_TBBem] Money NULL,
	[DFDiferenca_aliquota_TBBem] Money NULL,
	[DFObservacao_TBBem] Nvarchar(300) NULL,
	[DFCaminho_Imagem_TBBem] Nvarchar(50) NULL,
	[DFInicio_depreciacao_TBBem] Smalldatetime NOT NULL,
	[DFStatus_TBBem] Integer Default 1 NOT NULL,
	[DFPercentual_residual_TBBem] Decimal(2,2) NULL,
	[FKCodigo_TBDepartamento] Integer NOT NULL,
	[FKCodigo_TBEmpresa] Integer NOT NULL,
	[IXCodigo_empresa_locada_TBBEm] Integer NOT NULL,
	[IXCodigo_departamento_locado_TBBem] Integer NOT NULL,
Primary Key ([PKCodigo_TBBem])
) 
go

Create table [TBSituacao] (
	[PKCodigo_TBSituacao] Integer NOT NULL,
	[DFDescricao_TBSituacao] Nvarchar(40) NOT NULL,
Primary Key ([PKCodigo_TBSituacao])
) 
go

Create table [TBClasse] (
	[PKCodigo_TBClasse] Integer NOT NULL,
	[DFDescricao_TBClasse] Nvarchar(40) NOT NULL,
	[DFPercentual_depreciacao_TBClasse] Decimal(3,2) NOT NULL,
	[DFConta_contabil_TBClasse] Float NULL,
Primary Key ([PKCodigo_TBClasse])
) 
go

Create table [TBDepartamento] (
	[PKCodigo_TBDepartamento] Integer NOT NULL,
	[DFDescricao_TBDepartamento] Nvarchar(40) NOT NULL,
Primary Key ([PKCodigo_TBDepartamento])
) 
go

Create table [TBDescricao_padrao] (
	[PKId_TBDescricao_padrao] Integer Identity NOT NULL,
	[DFDescricao_padrao] Nvarchar(40) NOT NULL,
Primary Key ([PKId_TBDescricao_padrao])
) 
go

Create table [TBDepreciacao] (
	[PKId_TBDeprecicao] Integer Identity NOT NULL,
	[FKCodigo_TBBem] Integer NOT NULL,
	[DFData_TBDepreciacao] Smalldatetime NOT NULL,
	[DFValor_TBDepreciacao] Money NOT NULL,
Primary Key ([PKId_TBDeprecicao])
) 
go

Create table [TBHistorico_movimentacao] (
	[DFId_TBHistorico_movimentacao] Integer Identity NOT NULL,
	[FKCodigo_TBBem] Integer NOT NULL,
	[DFCodigo_empresa_origem_TBHistorico_movimentacao] Integer NOT NULL,
	[DFCodigo_departamento_origem_TBHistorico_movimentacao] Integer NOT NULL,
	[DFCodigo_empresa_destino_TBHistorico_movimentacao] Integer NOT NULL,
	[DFCodigo_departamento_destino_TBHistorico_movimentacao] Integer NOT NULL,
	[DFData_TBHistorico_movimentacao] Smalldatetime NOT NULL,
	[DFUsuario_TBHistorico_movimentacao] Nvarchar(30) NOT NULL,
Primary Key ([DFId_TBHistorico_movimentacao])
) 
go

Create table [TBManutencao] (
	[PKId_TBManutencao] Integer Identity NOT NULL,
	[FKCodigo_TBBem] Integer NOT NULL,
	[FKCodigo_TBFornecedor] Integer NOT NULL,
	[DFDataTBManutencao] Smalldatetime NOT NULL,
	[DFValor_TBManutencao] Money NOT NULL,
	[DFMotivo_TBManutencao] Nvarchar(40) NOT NULL,
	[DFNumero_doc_TBManutencao] Integer NOT NULL,
Primary Key ([PKId_TBManutencao])
) 
go

Create table [TBComposicao_bem] (
	[PKId_TBComposicao] Integer Identity NOT NULL,
	[FKCodigo_TBBem] Integer NOT NULL,
	[FKCodigo_TBComposicao_padrao] Integer NOT NULL,
	[DFComplemento_TBComposicao] Nvarchar(40) NULL,
	[DFObservacao_TBComposicao] Nvarchar(40) NULL,
	[DFQuantidade_TBComposicao] Integer NULL,
Primary Key ([PKId_TBComposicao])
) 
go

Create table [TBComposicao_padrao] (
	[PKCodigo_TBComposicao_padrao] Integer NOT NULL,
	[DFDescricao_TBComposicao_padrao] Nvarchar(40) NOT NULL,
Primary Key ([PKCodigo_TBComposicao_padrao])
) 
go

Create table [TBBaixa_bem] (
	[FKCodigo_TBBem] Integer NOT NULL,
	[DFData_TBBaixa_bem] Smalldatetime NOT NULL,
	[DFValor_TBBAixa_bem] Money NOT NULL,
	[DFTipo_documento_TBBaixa] Bit NOT NULL,
	[DFNumero_doc_TBBaixa_bem] Integer NOT NULL,
	[DFMotivo_TBBaixa_bem] Nvarchar(40) NOT NULL,
Primary Key ([FKCodigo_TBBem])
) 
go

Create table [TBProduto_estrutura_mercadologica] (
	[PKId_TBProduto_estrutura_mercadologica] Integer Identity NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[FKId_TBCategoria] Integer NOT NULL,
Primary Key ([PKId_TBProduto_estrutura_mercadologica])
) 
go

Create table [TBGiro_produto] (
	[PKId_TBGiro_produto] Integer Identity NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[DFQuantidade_vendida_TBGiro_produto] Decimal(10,3) NOT NULL,
	[DFValor_total_venda_TBGiro_produto] Money NOT NULL,
	[DFCusto_bruto_total_TBGiro_produto] Money NOT NULL,
	[DFCusto_liquido_total_TBGiro_produto] Money NOT NULL,
	[DFCusto_medio_total_TBGiro_produto] Money NOT NULL,
	[DFData_TBGiro_produto] Smalldatetime NOT NULL,
	[PKCodigo_TBEmpresa] Integer NOT NULL,
Primary Key ([PKId_TBGiro_produto])
) 
go

Create table [TBKit_produto] (
	[PKId_TBKit_produto] Integer Identity NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[DFCodigo_TBKit_produto] Integer NOT NULL,
	[DFDescricao_TBKit_produto] Nvarchar(40) NOT NULL,
	[DFQuantidade_TBKit_produto] Decimal(10,3) NOT NULL,
	[DFPreco_unitario_TBKit_produto] Money NOT NULL,
Primary Key ([PKId_TBKit_produto])
) 
go

Create table [TBTecnico] (
	[PKCodigo_TBTecnico] Integer NOT NULL,
	[DFNome_TBTecnico] Nvarchar(40) NOT NULL,
	[DFTelefone_TBTecnico] Nvarchar(20) NOT NULL,
	[DFCelular_TBTecnico] Nvarchar(20) NULL,
	[DFEmail_TBTecnico] Nvarchar(40) NULL,
	[DFValor_hora_TBTecnico] Money NULL,
	[DFValor_hora_noturna_TBTecnico] Money NULL,
Primary Key ([PKCodigo_TBTecnico])
) 
go

Create table [TBClassificacao] (
	[PKCodigo_TBClassificacao] Integer NOT NULL,
	[DFDescricao_TBClassificacao] Nvarchar(40) NOT NULL,
Primary Key ([PKCodigo_TBClassificacao])
) 
go

Create table [TBSolicitacao_helpdesk] (
	[PKIdSolicitacao_helpdesk] Integer Identity NOT NULL,
	[FKCodigo_TBDepartamento] Integer NOT NULL,
	[FKCodigo_TBEmpresa] Integer NOT NULL,
	[DFAtendente_TBSolicitacao_helpdesk] Nvarchar(40) NOT NULL,
	[DFTelefone_solicitante_TBSolicitacao_helpdesk] Nvarchar(20) NULL,
	[DFEmail_TBSolicitacao_helpdesk] Nvarchar(40) NULL,
	[DFData_atendimento_TBSolicitacao_helpdesk] Smalldatetime NOT NULL,
	[DFSolicitante_TBSolicitacao_helpdesk] Nvarchar(40) NOT NULL,
	[FKCodigo_TBClassificacao] Integer NOT NULL,
	[DFStatus_TBSolicitacao_helpdesk] Integer NOT NULL,
	[DFTipo_TBSolicitacao_helpdesk] Integer NULL,
	[DFPrioridade_TBSolicitacao_helpdesk] Integer NOT NULL,
	[DFDescricao_TBSolicitacao_helpdesk] Nvarchar(400) NOT NULL,
	[FKCodigo_TBTecnico] Integer NOT NULL,
	[DFData_inicio_TBSolicitacao_helpdesk] Smalldatetime NULL,
	[DFData_final_TBSolicitacao_helpdesk] Smalldatetime NULL,
	[DFSolucao_TBSolicitacao_helpdesk] Nvarchar(400) NULL,
	[DFObservacao_TBSolicitacao_helpdesk] Nvarchar(40) NULL,
	[DFCusto_mao_de_obra_TBSolicitacao_helpdesk] Money NULL,
	[DFCusto_deslocamento_TBSolicitacao_helpdesk] Money NULL,
	[DFCusto_material_TBSolicitacao_helpdesk] Money NULL,
Primary Key ([PKIdSolicitacao_helpdesk])
) 
go

Create table [TBSoftware] (
	[PKId_TBSoftware] Integer Identity NOT NULL,
	[FKId_Tipo_software] Integer NOT NULL,
	[DFPart_number_TBSoftware] Nvarchar(10) NULL,
	[DFDescricao_TBSofware] Nvarchar(40) NOT NULL,
Primary Key ([PKId_TBSoftware])
) 
go

Create table [TBTipo_software] (
	[PKId_Tipo_software] Integer Identity NOT NULL,
	[DFDescricao_TBTipo_software] Nvarchar(40) NOT NULL,
Primary Key ([PKId_Tipo_software])
) 
go

Create table [TBLicenca] (
	[PKId_TBLicenca] Integer Identity NOT NULL,
	[FKId_TBSituacao_software] Integer NOT NULL,
	[FKCodigo_TBEmpresa] Integer NOT NULL,
	[FKId_TBSoftware] Integer NOT NULL,
	[FKCodigo_TBFornecedor] Integer NOT NULL,
	[DFData_TBLicenca] Smalldatetime NOT NULL,
	[DFData_recompra_TBLincenca] Smalldatetime NOT NULL,
	[DFNumero_autorizacao_TBLicenca] Nvarchar(20) NULL,
	[DFNumero_contrato_TBLicenca] Nvarchar(20) NULL,
	[DFTipo_TBLicenca] Nvarchar(10) NOT NULL,
	[DFNumero_nota_TBlicenca] Integer NOT NULL,
	[DFQuantidade_TBLicenca] Integer NULL,
	[DFValor_TBLicenca] Money NOT NULL,
	[DFObservacao_TBLicenca] Nvarchar(200) NULL,
	[DFChave_instalacao_TBLicenca] Nvarchar(40) NULL,
	[DFTipo_aquisicao_TBLicenca] Bit NULL,
	[DFVinculo_TBLicenca] Integer NULL,
Primary Key ([PKId_TBLicenca])
) 
go

Create table [TBLicenca_equipamento] (
	[PKId_Licenca_equipamento] Integer Identity NOT NULL,
	[FKId_TBLicenca] Integer NOT NULL,
	[FKCodigo_TBBem] Integer NOT NULL,
Primary Key ([PKId_Licenca_equipamento])
) 
go

Create table [TBHardware_solicitacao] (
	[PKId_TBHardware_solicitacao] Integer Identity NOT NULL,
	[FKIdSolicitacao_helpdesk] Integer NOT NULL,
	[FKCodigo_TBBem] Integer NOT NULL,
Primary Key ([PKId_TBHardware_solicitacao])
) 
go

Create table [TBOcorrencia_estoque] (
	[PKId_TBOcorrencia_estoque] Integer Identity NOT NULL,
	[FKCodigo_TBEmpresa] Integer NOT NULL,
	[FKCodigo_TBProduto] Integer NOT NULL,
	[DFEstoque_anterior_PKId_TBOcorrencia_estoque] Decimal(12,3) NOT NULL,
	[DFQuantidade_movimentada_PKId_TBOcorrencia_estoque] Decimal(12,3) NOT NULL,
	[DFEstoque_atualizado_PKId_TBOcorrencia_estoque] Decimal(12,3) NOT NULL,
	[DFData_PKId_TBOcorrencia_estoque] Smalldatetime NOT NULL,
	[DFUsuario_PKId_TBOcorrencia_estoque] Nvarchar(20) NOT NULL,
	[DFNumero_doc_PKId_TBOcorrencia_estoque] Integer NOT NULL,
	[DFPrograma_PKId_TBOcorrencia_estoque] Nvarchar(20) NOT NULL,
Primary Key ([PKId_TBOcorrencia_estoque])
) 
go

Create table [TBSituacao_software] (
	[PKId_TBSituacao_software] Integer Identity NOT NULL,
	[DFDescricao_TBSituacao_software] Nvarchar(40) NOT NULL,
Primary Key ([PKId_TBSituacao_software])
) 
go

Create table [TBModulo] (
	[PKId_TBModulo] Integer Identity NOT NULL,
	[FKId_TBSubmenu] Integer NOT NULL,
	[DFDescricao_TBModulo] Nvarchar(20) NOT NULL,
Primary Key ([PKId_TBModulo])
) 
go

Create table [TBAcessibilidade_grupo] (
	[PKId_TBAcessibilidade_grupo] Integer Identity NOT NULL,
	[FKId_TBModulo] Integer NOT NULL,
	[FKCodigo_TBGrupo_usuario] Integer NOT NULL,
	[DFInclusao_TBAcessibilidade_grupo] Bit NOT NULL,
	[DFExclusao_TBAcessibilidade_grupo] Bit NOT NULL,
	[DFConsulta_TBAcessibilidade_grupo] Bit NOT NULL,
	[DFAlteracao_TBAcessibilidade_grupo] Bit NOT NULL,
	[DFAcesso_TBAcessibilidade_grupo] Bit NOT NULL,
Primary Key ([PKId_TBAcessibilidade_grupo])
) 
go

Create table [TBUsuario_grupo] (
	[PKId_TBUsuario_grupo] Integer Identity NOT NULL,
	[FKCodigo_TBUsuario] Integer NOT NULL,
	[FKCodigo_TBGrupo_usuario] Integer NOT NULL,
Primary Key ([PKId_TBUsuario_grupo])
) 
go





































































Alter table [TBAcessibilidade_grupo] add  foreign key([FKCodigo_TBGrupo_usuario]) references [TBGrupo_usuario] ([PKCodigo_TBGrupo_usuario])  on update no action on delete no action 
go
Alter table [TBUsuario_grupo] add  foreign key([FKCodigo_TBGrupo_usuario]) references [TBGrupo_usuario] ([PKCodigo_TBGrupo_usuario])  on update no action on delete no action 
go
Alter table [TBSubmenu] add  foreign key([FKId_TBMenu]) references [TBMenu] ([PKId_TBMenu])  on update no action on delete no action 
go
Alter table [TBModulo] add  foreign key([FKId_TBSubmenu]) references [TBSubmenu] ([PKId_TBSubmenu])  on update no action on delete no action 
go
Alter table [TBUsuario] add  foreign key([FKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [TBProduto_empresa] add  foreign key([FKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [TBBem] add  foreign key([FKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [TBGiro_produto] add  foreign key([PKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [TBSolicitacao_helpdesk] add  foreign key([FKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [TBLicenca] add  foreign key([FKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [TBOcorrencia_estoque] add  foreign key([FKCodigo_TBEmpresa]) references [TBEmpresa] ([PKCodigo_TBEmpresa])  on update no action on delete no action 
go
Alter table [dbo].[TBLogradouro] add  foreign key([FKBairro_seq_inicial_TBLogradouro]) references [TBBairro] ([PKCodigo_TBBairro])  on update no action on delete no action 
go
Alter table [dbo].[TBLogradouro] add  foreign key([FKCodigo_cidade_TBLogradouro]) references [TBCidade] ([PKCodigo_TBCidade])  on update no action on delete no action 
go
Alter table [TBSecao] add  foreign key([FKCodigo_TBEstrutura_mercadologica]) references [TBEstrutura_mercadologica] ([PKCodigo_TBEstrutura_mercadologica])  on update no action on delete no action 
go
Alter table [TBGrupo] add  foreign key([FKId_TBSecao]) references [TBSecao] ([PKId_TBSecao])  on update no action on delete no action 
go
Alter table [TBSubgrupo] add  foreign key([FKId_TBGrupo]) references [TBGrupo] ([PKId_TBGrupo])  on update no action on delete no action 
go
Alter table [TBCategoria] add  foreign key([FKId_TBSubgrupo]) references [TBSubgrupo] ([PKId_TBSubgrupo])  on update no action on delete no action 
go
Alter table [TBProduto_estrutura_mercadologica] add  foreign key([FKId_TBCategoria]) references [TBCategoria] ([PKId_TBCategoria])  on update no action on delete no action 
go
Alter table [TBFornecedor_filial] add  foreign key([PKCodigo_TBFornecedor]) references [TBFornecedor] ([PKCodigo_TBFornecedor])  on update no action on delete no action 
go
Alter table [TBAgenda_fornecedor] add  foreign key([FKCodigo_TBFornecedor]) references [TBFornecedor] ([PKCodigo_TBFornecedor])  on update no action on delete no action 
go
Alter table [TBProduto_fornecedor] add  foreign key([PKCodigo_TBFornecedor]) references [TBFornecedor] ([PKCodigo_TBFornecedor])  on update no action on delete no action 
go
Alter table [TBBem] add  foreign key([FKCodigo_TBFornecedor]) references [TBFornecedor] ([PKCodigo_TBFornecedor])  on update no action on delete no action 
go
Alter table [TBManutencao] add  foreign key([FKCodigo_TBFornecedor]) references [TBFornecedor] ([PKCodigo_TBFornecedor])  on update no action on delete no action 
go
Alter table [TBLicenca] add  foreign key([FKCodigo_TBFornecedor]) references [TBFornecedor] ([PKCodigo_TBFornecedor])  on update no action on delete no action 
go
Alter table [TBProduto] add  foreign key([FKCodigo_TBComprador]) references [TBComprador] ([PKCodigo_TBComprador])  on update no action on delete no action 
go
Alter table [TBFornecedor] add  foreign key([FKCodigo_TBCondicao_pagamento]) references [TBCondicao_pagamento] ([PKCodigo_TBCondicao_pagamento])  on update no action on delete no action 
go
Alter table [TBEmpresa] add  foreign key([FKId_TBCidade_gestor]) references [TBCidade_gestor] ([PKId_TBCidade_gestor])  on update no action on delete no action 
go
Alter table [TBFornecedor_filial] add  foreign key([FKId_TBCidade_gestor]) references [TBCidade_gestor] ([PKId_TBCidade_gestor])  on update no action on delete no action 
go
Alter table [TBObra] add  foreign key([FKId_TBCidade_gestor]) references [TBCidade_gestor] ([PKId_TBCidade_gestor])  on update no action on delete no action 
go
Alter table [TBClientes_construtora] add  foreign key([FKId_TBCidade_gestor]) references [TBCidade_gestor] ([PKId_TBCidade_gestor])  on update no action on delete no action 
go
Alter table [TBFornecedor] add  foreign key([FKCodigo_TBBanco]) references [TBBanco] ([PKCodigo_TBBanco])  on update no action on delete no action 
go
Alter table [TBAgenda_clientes_construtora] add  foreign key([FKCodigo_TBClientes_construtora]) references [TBClientes_construtora] ([PKCodigo_TBClientes_construtora])  on update no action on delete no action 
go
Alter table [TBSolicitacao_servico] add  foreign key([FKCodigo_TBClientes_construtora]) references [TBClientes_construtora] ([PKCodigo_TBClientes_construtora])  on update no action on delete no action 
go
Alter table [TBOrdem_servico] add  foreign key([FKCodigo_TBSolicitacao_servico]) references [TBSolicitacao_servico] ([PKCodigo_TBSolicitacao_servico])  on update no action on delete no action 
go
Alter table [TBCusto_servico] add  foreign key([PKCodigo_TBCusto_servico]) references [TBOrdem_servico] ([PKCodigo_TBOrdem_servico])  on update no action on delete no action 
go
Alter table [TBCusto_detalhamento] add  foreign key([FKCodigo_TBCusto_servico]) references [TBCusto_servico] ([PKCodigo_TBCusto_servico])  on update no action on delete no action 
go
Alter table [TBBem] add  foreign key([FKId_TBClassificacao_fiscal]) references [TBClassificacao_fiscal] ([PKId_TBClassificacao_fiscal])  on update no action on delete no action 
go
Alter table [TBProduto_fornecedor] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBCodigo_barras] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBProduto_empresa] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBProduto_estrutura_mercadologica] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBGiro_produto] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBKit_produto] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBOcorrencia_estoque] add  foreign key([FKCodigo_TBProduto]) references [TBProduto] ([PKCodigo_TBProduto])  on update no action on delete no action 
go
Alter table [TBManutencao] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBDepreciacao] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBComposicao_bem] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBBaixa_bem] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBHistorico_movimentacao] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBLicenca_equipamento] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBHardware_solicitacao] add  foreign key([FKCodigo_TBBem]) references [TBBem] ([PKCodigo_TBBem])  on update no action on delete no action 
go
Alter table [TBBem] add  foreign key([FKCodigo_TBSituacao]) references [TBSituacao] ([PKCodigo_TBSituacao])  on update no action on delete no action 
go
Alter table [TBBem] add  foreign key([FKCodigo_TBClasse]) references [TBClasse] ([PKCodigo_TBClasse])  on update no action on delete no action 
go
Alter table [TBBem] add  foreign key([FKCodigo_TBDepartamento]) references [TBDepartamento] ([PKCodigo_TBDepartamento])  on update no action on delete no action 
go
Alter table [TBSolicitacao_helpdesk] add  foreign key([FKCodigo_TBDepartamento]) references [TBDepartamento] ([PKCodigo_TBDepartamento])  on update no action on delete no action 
go
Alter table [TBComposicao_bem] add  foreign key([FKCodigo_TBComposicao_padrao]) references [TBComposicao_padrao] ([PKCodigo_TBComposicao_padrao])  on update no action on delete no action 
go
Alter table [TBSolicitacao_helpdesk] add  foreign key([FKCodigo_TBTecnico]) references [TBTecnico] ([PKCodigo_TBTecnico])  on update no action on delete no action 
go
Alter table [TBSolicitacao_helpdesk] add  foreign key([FKCodigo_TBClassificacao]) references [TBClassificacao] ([PKCodigo_TBClassificacao])  on update no action on delete no action 
go
Alter table [TBHardware_solicitacao] add  foreign key([FKIdSolicitacao_helpdesk]) references [TBSolicitacao_helpdesk] ([PKIdSolicitacao_helpdesk])  on update no action on delete no action 
go
Alter table [TBLicenca] add  foreign key([FKId_TBSoftware]) references [TBSoftware] ([PKId_TBSoftware])  on update no action on delete no action 
go
Alter table [TBSoftware] add  foreign key([FKId_Tipo_software]) references [TBTipo_software] ([PKId_Tipo_software])  on update no action on delete no action 
go
Alter table [TBLicenca_equipamento] add  foreign key([FKId_TBLicenca]) references [TBLicenca] ([PKId_TBLicenca])  on update no action on delete no action 
go
Alter table [TBLicenca] add  foreign key([FKId_TBSituacao_software]) references [TBSituacao_software] ([PKId_TBSituacao_software])  on update no action on delete no action 
go
Alter table [TBAcessibilidade] add  foreign key([FKId_TBModulo]) references [TBModulo] ([PKId_TBModulo])  on update no action on delete no action 
go
Alter table [TBAcessibilidade_grupo] add  foreign key([FKId_TBModulo]) references [TBModulo] ([PKId_TBModulo])  on update no action on delete no action 
go


Set quoted_identifier on
go












Set quoted_identifier off
go








/* Roles permissions */





/* Users permissions */





