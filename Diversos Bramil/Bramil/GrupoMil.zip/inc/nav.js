function getTheObject(id) {
	if (navigator.appName.toLowerCase().indexOf("netscape") > -1) {
		return document.getElementById(id);
	} else {
		return document.all[id];
	}
}

function expLinks(expID){
	if ((expID != null) && (expID != "")){
		var obj1 = getTheObject(expID);
		var obj2 = getTheObject(expID + "_img");

		if (obj1 != null){
			if (obj1.style.display == "block"){
				obj1.style.display = "none";
				obj2.src = "img/closed.gif";
			} else{
//				if (navigator.appName.toLowerCase().indexOf("netscape") > -1) {
//					obj1.style.display = "f";
//				} else {
					obj1.style.display = "block";				
//				}
				obj2.src = "img/open.gif";
				
				// START CODE TO COLLAPSE OTHER MENUS
				if(expID == 'compras') {
					if(getTheObject("financeiro").style.display == 'block')
						expLinks('financeiro');
					if(getTheObject("OperationalPractices").style.display == 'block')
						expLinks('OperationalPractices');
				} else	if(expID == 'financeiro') {
					if(getTheObject("compras").style.display == 'block')
						expLinks('compras');
					if(getTheObject("OperationalPractices").style.display == 'block')
						expLinks('OperationalPractices');
				} else {
					if(getTheObject("compras").style.display == 'block')
						expLinks('compras');
					if(getTheObject("financeiro").style.display == 'block')
						expLinks('financeiro');
				}				

				// END OF CODE COLLAPSE OTHER MENUS
			}
		}
	}
}

function initPage(){
	var loc;
	loc = window.location;
	expLinks(getSubfolder(loc));
}

function getSubfolder(path){
	var pos
	
	path = path.toString();
	path = path.replace("http://","");
	pos = path.indexOf("/");
	path = path.substr(pos+1, path.length);
	path = path.substr(0,path.indexOf("/"));
	path = path.toUpperCase()
	return path;
}

initPage();