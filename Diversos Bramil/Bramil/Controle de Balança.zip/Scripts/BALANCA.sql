/*            SCRIPT GERADO PELO Dr.CASE 3.10                                        */
/*                                                                                   */
/*                                                                                   */
/*  Data:    08/08/2002                                                              */
/*  Hora:    16:25                                                                   */
/*  Script:  MS SQL Server 2000                                                      */
/*  Op��es:                                                                          */
/*           Gerar nomes �nicos para constraints                                     */
/*           Utilizar acentua��o em nomes                                            */
/*           Gerar valida��o de campos                                               */
/*           N�o mapear regra de integridade referencial via trigger.                */
/*           Defini��o de constraints ap�s a defini��o de todas as tabelas.          */





/*  Cria��o da tabela TBBalanca (TBBalanca)                                          */
CREATE TABLE TBBalanca ( 
       numero_balanca                INT        NOT NULL,
       marca_balanca                 VARCHAR(30) NULL,
       capacidade_balanca            VARCHAR(20) NULL,
       numero_inmetro                VARCHAR(20) NULL,
       codigo_empresa                VARCHAR(8) NULL)
go

/*  Cria��o da tabela TBEmpresa (TBEmpresa)                                          */
CREATE TABLE TBEmpresa ( 
       codigo_empresa                VARCHAR(8) NOT NULL,
       descricao_empresa             VARCHAR(30) NULL)
go

/*  Cria��o da tabela TBmanutencaobalanca (TBmanutencaobalanca)                      */
CREATE TABLE TBmanutencaobalanca ( 
       codigo_manutencao             INT        NOT NULL,
       data_manutencao               SMALLDATETIME NULL,
       descricao_manutencao          NVARCHAR(250) NULL,
       numero_etiqueta               NVARCHAR(20) NULL,
       numero_balanca                INT        NULL)
go

/*  Cria��o da tabela TBTransferencia (TBTransferencia)                              */
CREATE TABLE TBTransferencia ( 
       codigo_transferencia          INT        NOT NULL,
       data_transferencia            SMALLDATETIME NULL,
       numero_balanca                INT        NULL,
       codigo_empresa                VARCHAR(8) NULL,
       codigo_empresa_1              VARCHAR(8) NULL)
go

/*  Cria��o da tabela TBusuario (TBusuario)                                          */
CREATE TABLE TBusuario ( 
       codigo_usuario                INT        NOT NULL,
       nome_usuario                  VARCHAR(30) NOT NULL,
       senha_usuario                 VARCHAR(8) NOT NULL)
go

/*  Cria��o da tabela TBlog (TBlog)                                                  */
CREATE TABLE TBlog ( 
       id_Log                        INT        NOT NULL,
       data_log                      SMALLDATETIME NULL,
       hora_log                      VARCHAR(10) NULL,
       programa_log                  VARCHAR(30) NULL,
       documento_log                 VARCHAR(30) NULL,
       acao_log                      VARCHAR(40) NULL,
       observacao_log                VARCHAR(80) NULL,
       usuario_log                   VARCHAR(20) NULL)
go

/*  Cria��o da tabela TBbaixa (TBbaixa)                                              */
CREATE TABLE TBbaixa ( 
       codigo_baixa                  INT        NOT NULL,
       data_baixa                    SMALLDATETIME NULL,
       motivo_baixa                  VARCHAR(250) NULL,
       numero_balanca                INT        NULL)
go

/*  Cria��o de chave prim�ria PK_TBBalanca (PrimaryKey) da tabela TBBalanca (TBBalanca) */
ALTER TABLE TBBalanca ADD CONSTRAINT PK_TBBalanca PRIMARY KEY(numero_balanca)
go

/*  Cria��o de chave prim�ria PK_TBEmpresa (PrimaryKey) da tabela TBEmpresa (TBEmpresa) */
ALTER TABLE TBEmpresa ADD CONSTRAINT PK_TBEmpresa PRIMARY KEY(codigo_empresa)
go

/*  Cria��o de chave prim�ria PK_TBmanutencaobalanca (PrimaryKey) da tabela TBmanutencaobalanca (TBmanutencaobalanca) */
ALTER TABLE TBmanutencaobalanca ADD CONSTRAINT PK_TBmanutencaobalanca PRIMARY KEY(codigo_manutencao)
go

/*  Cria��o de chave prim�ria PK_TBTransferencia (PrimaryKey) da tabela TBTransferencia (TBTransferencia) */
ALTER TABLE TBTransferencia ADD CONSTRAINT PK_TBTransferencia PRIMARY KEY(codigo_transferencia)
go

/*  Cria��o de chave prim�ria PK_TBusuario (PrimaryKey) da tabela TBusuario (TBusuario) */
ALTER TABLE TBusuario ADD CONSTRAINT PK_TBusuario PRIMARY KEY(codigo_usuario)
go

/*  Cria��o de chave prim�ria PK_TBlog (PrimaryKey) da tabela TBlog (TBlog)          */
ALTER TABLE TBlog ADD CONSTRAINT PK_TBlog PRIMARY KEY(id_Log)
go

/*  Cria��o de chave prim�ria PK_TBbaixa (PrimaryKey) da tabela TBbaixa (TBbaixa)    */
ALTER TABLE TBbaixa ADD CONSTRAINT PK_TBbaixa PRIMARY KEY(codigo_baixa)
go

/*  Cria��o das chaves estrangeiras da tabela TBBalanca                              */
/*  Cria��o da chave estrangeira FK_TBBalanca1_TBEmp (CE_TBBalanca_TBEmpresa_1)      */
ALTER TABLE TBBalanca ADD CONSTRAINT FK_TBBalanca1_TBEmp FOREIGN KEY(codigo_empresa) REFERENCES TBEmpresa
go

/*  Cria��o das chaves estrangeiras da tabela TBmanutencaobalanca                    */
/*  Cria��o da chave estrangeira FK_TBmanutencaobalanca1_T7055 (CE_TBmanutencaobalanca_TBBalanca_1) */
ALTER TABLE TBmanutencaobalanca ADD CONSTRAINT FK_TBmanutencaobalanca1_T5334 FOREIGN KEY(numero_balanca) REFERENCES TBBalanca
go

/*  Cria��o das chaves estrangeiras da tabela TBTransferencia                        */
/*  Cria��o da chave estrangeira FK_TBTransferencia1_TBBal (CE_TBTransferencia_TBBalanca_1) */
ALTER TABLE TBTransferencia ADD CONSTRAINT FK_TBTransferencia1_TBBal FOREIGN KEY(numero_balanca) REFERENCES TBBalanca
go

/*  Cria��o da chave estrangeira FK_TBTransferencia2_TBEmp (CE_TBTransferencia_TBEmpresa_1) */
ALTER TABLE TBTransferencia ADD CONSTRAINT FK_TBTransferencia2_TBEmp FOREIGN KEY(codigo_empresa) REFERENCES TBEmpresa
go

/*  Cria��o da chave estrangeira FK_TBTransferencia3_TBEmp (CE_TBTransferencia_TBEmpresa_2) */
ALTER TABLE TBTransferencia ADD CONSTRAINT FK_TBTransferencia3_TBEmp FOREIGN KEY(codigo_empresa_1) REFERENCES TBEmpresa
go

/*  Cria��o das chaves estrangeiras da tabela TBbaixa                                */
/*  Cria��o da chave estrangeira FK_TBbaixa1_TBBal (CE_TBbaixa_TBBalanca_1)          */
ALTER TABLE TBbaixa ADD CONSTRAINT FK_TBbaixa1_TBBal FOREIGN KEY(numero_balanca) REFERENCES TBBalanca
go


